import { InrPipe } from './inr.pipe';

describe('InrPipe', () => {
  it('create an instance', () => {
    const pipe = new InrPipe();
    expect(pipe).toBeTruthy();
  });
});
