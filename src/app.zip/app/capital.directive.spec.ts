import { CapitalDirective } from './capital.directive';

// describe('CapitalDirective', () => {
//   it('should create an instance', () => {
//     const directive = new CapitalDirective();
//     expect(directive).toBeTruthy();
//   });
// });
