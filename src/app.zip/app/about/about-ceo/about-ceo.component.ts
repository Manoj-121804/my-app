import { Component } from '@angular/core';

@Component({
  selector: 'app-about-ceo',
  templateUrl: './about-ceo.component.html',
  styleUrls: ['./about-ceo.component.css']
})
export class AboutCeoComponent {

}
